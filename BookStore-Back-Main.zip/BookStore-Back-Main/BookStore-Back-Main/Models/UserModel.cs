﻿using Microsoft.AspNetCore.Identity;

namespace BookStore_Back_Main.Models
{
    public class UserModel : IdentityUser
    {
        public string Name { get; set; }

        public IList<CartItemModel>? Cart { get; set; }

        public bool IsAdmin { get; set; } = false;

        public UserModel()
        {
            Cart = new List<CartItemModel>();
        }
    }
}
