﻿using System.ComponentModel.DataAnnotations;

namespace BookStore_Back_Main.Models
{
    public class NewBookModel
    {
        public Guid Id { get; set; }    
        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public string Author { get; set; }

        [Required]
        public double Price { get; set; }

        [Required]
        public string Image { get; set; }

    }
}
