﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BookStore_Back_Main.Models
{
    public class CartItemModel
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid BookId { get; set; }
        public int Quantity { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]//העמודה תיווצר אוטומטית עם ערך ייחודי לכל משתמש חדש
        public string UserModelId { get; set; }

        public BookModel? Book { get; set; }//לניווט -  יכול להיות נאל ואז לא צריך אותו בגוף הבקשה
    }
}
