﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BookStore_Back_Main.Migrations
{
    /// <inheritdoc />
    public partial class changeToDataBaseAnnotation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
