﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BookStore_Back_Main.Migrations
{
    /// <inheritdoc />
    public partial class AddCartItem : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CartItemModel_AspNetUsers_UserModelId",
                table: "CartItemModel");

            migrationBuilder.AlterColumn<string>(
                name: "UserModelId",
                table: "CartItemModel",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_CartItemModel_BookId",
                table: "CartItemModel",
                column: "BookId");

            migrationBuilder.AddForeignKey(
                name: "FK_CartItemModel_AspNetUsers_UserModelId",
                table: "CartItemModel",
                column: "UserModelId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CartItemModel_Books_BookId",
                table: "CartItemModel",
                column: "BookId",
                principalTable: "Books",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CartItemModel_AspNetUsers_UserModelId",
                table: "CartItemModel");

            migrationBuilder.DropForeignKey(
                name: "FK_CartItemModel_Books_BookId",
                table: "CartItemModel");

            migrationBuilder.DropIndex(
                name: "IX_CartItemModel_BookId",
                table: "CartItemModel");

            migrationBuilder.AlterColumn<string>(
                name: "UserModelId",
                table: "CartItemModel",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddForeignKey(
                name: "FK_CartItemModel_AspNetUsers_UserModelId",
                table: "CartItemModel",
                column: "UserModelId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
