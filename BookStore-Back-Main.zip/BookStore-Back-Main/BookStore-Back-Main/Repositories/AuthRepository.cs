﻿using BookStore_Back_Main.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BookStore_Back_Main.Repositories
{
    public class AuthRepository : IAuthRepository
    {
        private readonly UserManager<UserModel> _userManager;
        private readonly SignInManager<UserModel> _signInManager;
        private readonly IConfiguration _configuration;

        public AuthRepository(UserManager<UserModel> userManager, SignInManager<UserModel> signInManager, IConfiguration configuration)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _configuration = configuration;
        }

        public async Task<string> Signup(SignupModel signupModel)
        {
            UserModel userModel = new()
            {
                Name = signupModel.Name,
                Email = signupModel.Email,
                UserName = signupModel.Email,
                IsAdmin = signupModel.Name.ToLower() == "admin" && signupModel.Password == "Admin123*",
            };
            var res = await _userManager.CreateAsync(userModel, signupModel.Password);
            if (res.Succeeded)
            {
                return userModel.Id;
            }
            return null;
        }

        public async Task<string> Login(LoginModel loginModel)
        {
            var res = await _signInManager.PasswordSignInAsync(loginModel.Email, loginModel.Password, false, false);
            if (!res.Succeeded)
            {
                return null;
            }
            var user = await _userManager.FindByEmailAsync(loginModel.Email);
            return CreateNewToken(user);
        }

        

        public async Task<UserModel> GetUserByEmailAsync(string email)
        {
            return await _userManager.FindByEmailAsync(email);
        }

        public async Task<bool> DeleteUserByIdAsync(string userId)
        {
            var user = await _userManager.FindByIdAsync(userId);

            if (user == null)
            {
                return false;
            }

            var result = await _userManager.DeleteAsync(user);

            return result.Succeeded;
        }

        public async Task<bool> UpdateUserProfileAsync(string userId, UpdateProfileModel updateModel)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return false;
            }

            user.Name = updateModel.Name;
            user.Email = updateModel.Email;
            user.UserName = updateModel.Email;

            if (!string.IsNullOrWhiteSpace(updateModel.Password))
            {
                var token = await _userManager.GeneratePasswordResetTokenAsync(user);
                var result = await _userManager.ResetPasswordAsync(user, token, updateModel.Password);
                if (!result.Succeeded)
                {
                    return false;
                }
            }

            var updateResult = await _userManager.UpdateAsync(user);
            return updateResult.Succeeded;
        }


        public string CreateNewToken(UserModel user)
        {
            var authClaims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Email),
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                 new Claim("IsAdmin", user.IsAdmin.ToString()),
                //new Claim(ClaimTypes.Role, user.IsAdmin ? "admin" : "user"),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var authSigninKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(_configuration["JWT:Secret"]));

            var token = new JwtSecurityToken(
                 issuer: _configuration["JWT:ValidIssuer"],//מי הנפיק את הטוקן
                audience: _configuration["JWT:ValidAudience"],//למי מיועד הטוקן
                expires: DateTime.Now.AddDays(1),
                claims: authClaims,
                signingCredentials: new SigningCredentials(authSigninKey, SecurityAlgorithms.HmacSha256Signature)//הגדרת מפתח החתימה
                );
            return new JwtSecurityTokenHandler().WriteToken(token);//המרת הטוקן למחרוזת טקסט
        }
    }
}
