﻿using BookStore_Back_Main.Models;

namespace BookStore_Back_Main.Repositories
{
    public interface IBookRepository
    {
        Task<List<BookModel>> GetAllBooksAsync();

        Task<BookModel> GetBookByIdAsync(Guid id);

        Task<Guid> CreateBookAsync(NewBookModel newBookModel);

        Task<bool> UpdateBookAsync(Guid bookId, NewBookModel updatedBook);

        Task<bool> DeleteBookAsync(Guid id);
    }
}