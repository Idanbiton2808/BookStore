﻿using BookStore_Back_Main.Data;
using BookStore_Back_Main.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore_Back_Main.Repositories
{
    public class BookRepository : IBookRepository
    {
        private readonly BookStoreDbContext _booksContext;

        public BookRepository(BookStoreDbContext context)
        {
            _booksContext = context;
        }

        public async Task<List<BookModel>> GetAllBooksAsync()
        {
            return await _booksContext.Books.ToListAsync();
        }

        public async Task<BookModel> GetBookByIdAsync(Guid id)
        {
            return await _booksContext.Books.FindAsync(id);
        }

        public async Task<Guid> CreateBookAsync(NewBookModel newBookModel)
        {
            BookModel bookModel = new()
            {
                Title = newBookModel.Title,
                Author = newBookModel.Author,
                Description = newBookModel.Description,
                Price = newBookModel.Price,
                Image = newBookModel.Image,
            };
            _booksContext.Books.Add(bookModel);
            var res = await _booksContext.SaveChangesAsync();
            if(res != 0)
            {
                return bookModel.Id;
            }
            return Guid.Empty;
        }

        public async Task<bool> UpdateBookAsync(Guid bookId, NewBookModel updatedBook)
        {
            var book = await _booksContext.Books.FindAsync(bookId);
            if (book == null) return false;

            book.Title = updatedBook.Title;
            book.Author = updatedBook.Author;
            book.Description = updatedBook.Description;
            book.Price = updatedBook.Price;
            book.Image = updatedBook.Image;

            _booksContext.Books.Update(book);
            await _booksContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteBookAsync(Guid id)
        {
            var book = await _booksContext.Books.FindAsync(id);
            if (book == null)
            {
                return false;
            }
             _booksContext.Books.Remove(book);
             await _booksContext.SaveChangesAsync();
             return true;    
        }
    }
}
