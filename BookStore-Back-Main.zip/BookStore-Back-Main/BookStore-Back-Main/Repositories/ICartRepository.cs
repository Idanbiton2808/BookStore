﻿using BookStore_Back_Main.Models;

namespace BookStore_Back_Main.Repositories
{
    public interface ICartRepository
    {
        Task<List<CartItemModel>> GetCartAsync(string userId);

        Task AddToCartAsync(string userId, CartItemModel item);
        Task AddItemsToCartAsync(string userId, List<CartItemModel> items);

        Task RemoveFromCartAsync(string userId, Guid bookId);

        Task<bool> UpdateCartItemAsync(string userId, CartItemModel updatedItem);

        Task ClearCartAsync(string userId);
    }
}