﻿using BookStore_Back_Main.Data;
using BookStore_Back_Main.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore_Back_Main.Repositories
{
    public class CartRepository : ICartRepository
    {
        private readonly BookStoreDbContext _dbContext;

        public CartRepository(BookStoreDbContext dbcontext)
        {
            _dbContext = dbcontext;
        }

        public async Task<List<CartItemModel>> GetCartAsync(string userId)
        {
            return await _dbContext.CartItemModel
                .Where(c => c.UserModelId == userId)
                .Include(c => c.Book) 
                .ToListAsync();
        }

        public async Task AddToCartAsync(string userId, CartItemModel item)
        {
            Console.WriteLine($"User ID: {userId}, Book ID: {item.BookId}");
            var existingItem = await _dbContext.CartItemModel
                .FirstOrDefaultAsync(c => c.UserModelId == userId && c.BookId == item.BookId);

            if (existingItem != null)
            {
                existingItem.Quantity += item.Quantity;
            }
            else
            {
                var newItem = new CartItemModel
                {
                    Id = Guid.NewGuid(),
                    BookId = item.BookId,
                    Quantity = item.Quantity,
                    UserModelId = userId
                };
                //item.UserModelId = userId;
                _dbContext.CartItemModel.Add(newItem);
            }

            await _dbContext.SaveChangesAsync();
        }




        public async Task AddItemsToCartAsync(string userId, List<CartItemModel> items)
        {
            var groupedItems = items
                .GroupBy(item => item.BookId)
                .Select(group => new CartItemModel
                {
                    BookId = group.Key,
                    Quantity = group.Sum(item => item.Quantity),
                    UserModelId = userId
                })
                .ToList();

            foreach (var item in groupedItems)
            {
                var existingItem = await _dbContext.CartItemModel
                    .FirstOrDefaultAsync(c => c.UserModelId == userId && c.BookId == item.BookId);

                if (existingItem != null)
                {
                    existingItem.Quantity += item.Quantity;
                }
                else
                {
                    _dbContext.CartItemModel.Add(item);
                }
            }

            await _dbContext.SaveChangesAsync();
        }


        public async Task RemoveFromCartAsync(string userId, Guid bookId)
        {
            var item = await _dbContext.CartItemModel
                .FirstOrDefaultAsync(c => c.UserModelId == userId && c.BookId == bookId);

            if (item != null)
            {
                _dbContext.CartItemModel.Remove(item);
                await _dbContext.SaveChangesAsync();
            }
        }

        public async Task<bool> UpdateCartItemAsync(string userId, CartItemModel updatedItem)
        {
            var existingItem = await _dbContext.CartItemModel
                .FirstOrDefaultAsync(c => c.UserModelId == userId && c.BookId == updatedItem.BookId);

            if (existingItem != null)
            {
                existingItem.Quantity = updatedItem.Quantity;
                await _dbContext.SaveChangesAsync();
                return true; 
            }

            return false; 
        }


        public async Task ClearCartAsync(string userId)
        {
            var items = await _dbContext.CartItemModel
                .Where(c => c.UserModelId == userId)
                .ToListAsync();

            _dbContext.CartItemModel.RemoveRange(items);
            await _dbContext.SaveChangesAsync();
        }
    }
}
