﻿using BookStore_Back_Main.Models;

namespace BookStore_Back_Main.Repositories
{
    public interface IAuthRepository
    {
        Task<string> Signup(SignupModel signupModel);

        Task<string> Login(LoginModel loginModel);

        Task<UserModel> GetUserByEmailAsync(string email);

        Task<bool> DeleteUserByIdAsync(string userId);

        Task<bool> UpdateUserProfileAsync(string userId, UpdateProfileModel updateModel);

        string CreateNewToken(UserModel user);
    }
}