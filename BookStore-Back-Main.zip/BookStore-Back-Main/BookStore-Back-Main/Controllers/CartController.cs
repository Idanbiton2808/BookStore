﻿using BookStore_Back_Main.Data;
using BookStore_Back_Main.Models;
using BookStore_Back_Main.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace BookStore_Back_Main.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly UserManager<UserModel> _userManager;
        private readonly ICartRepository _cartRepository;

        public CartController(UserManager<UserModel> userManager,ICartRepository cartRepository)
        {
            _userManager = userManager;
            _cartRepository = cartRepository;
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetCart()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null) return Unauthorized("User is not logged in.");

            var cartItems = await _cartRepository.GetCartAsync(userId);
            return Ok(cartItems);
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> AddToCart([FromBody] CartItemModel newItem)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null) return Unauthorized("User is not logged in.");

            await _cartRepository.AddToCartAsync(userId, newItem);
            //return Ok("Book added to cart.");
            return NoContent();
        }


        [Authorize]
        [HttpDelete("{bookId}")]
        public async Task<IActionResult> RemoveFromCart(Guid bookId)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null) return Unauthorized("User is not logged in.");

            await _cartRepository.RemoveFromCartAsync(userId, bookId);
            return Ok(new { message = "Book removed successfully." });
        }

        [HttpPost("update")]
        public async Task<IActionResult> UpdateCartItem([FromBody] CartItemModel updatedItem)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null) return Unauthorized("User is not logged in.");

            await _cartRepository.UpdateCartItemAsync(userId, updatedItem);
            return Ok(new { message = "Cart item updated successfully." }); //JSON
        }
    }
}
