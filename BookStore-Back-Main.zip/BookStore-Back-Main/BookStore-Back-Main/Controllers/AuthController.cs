﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BookStore_Back_Main.Repositories;
using BookStore_Back_Main.Models;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace BookStore_Back_Main.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        public readonly IAuthRepository _authRepository;

        public AuthController(IAuthRepository authRepository)
        {
            _authRepository = authRepository;
        }

        [HttpPost("signup")]
        public async Task<IActionResult> Signup([FromBody] SignupModel signupModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var res = await _authRepository.Signup(signupModel);
            if (string.IsNullOrWhiteSpace(res))
            {
                return Unauthorized(new { message = "User creation failed" });
            }
            return Ok(new { id = res });
        }


        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel loginModel)
        {
            var res = await _authRepository.Login(loginModel);
            if (string.IsNullOrWhiteSpace(res))
            {
                return BadRequest(new { message = "User creation failed" });
            }
            return Ok(new { res });
        }

        [HttpPost("admin/login")]
        public async Task<IActionResult> AdminLogin([FromBody] LoginModel loginModel)
        {
            var user = await _authRepository.GetUserByEmailAsync(loginModel.Email);
            if (user == null || !user.IsAdmin)
            {
                return Unauthorized(new { message = "Unauthorized: Admin access required." });
            }

            var token = await _authRepository.Login(loginModel);
            if (string.IsNullOrWhiteSpace(token))
            {
                return BadRequest(new { message = "Login failed." });
            }

            return Ok(new { token });
        }


        [HttpPost("logout")]
        public IActionResult Logout()
        {
            return Ok(new { message = "Logout successful" });
        }


        [Authorize]
        [HttpGet("getName")]
        public IActionResult GetNameFromToken()
        {
            try
            {
                var userId = User.FindFirst("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier")?.Value;
                var username = User.Identity?.Name;

                if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(username))
                {
                    throw new Exception("Missing user details in token");
                }
                var isAdminClaim = User.FindFirst("IsAdmin")?.Value;
                bool isAdmin = !string.IsNullOrEmpty(isAdminClaim) && bool.Parse(isAdminClaim);

                return Ok(new { id = userId, name = username ,isAdmin});
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error: " + ex.Message });
            }
        }


        [Authorize]
        [HttpDelete("{userId}")]
        public async Task<IActionResult> DeleteUser(string userId)
        {
            try
            {
                var success = await _authRepository.DeleteUserByIdAsync(userId);
                if (!success)
                {
                    return NotFound(new { message = "User not found." });
                }

                return Ok(new { message = "User deleted successfully." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error: " + ex.Message });
            }
        }

        [Authorize]
        [HttpPut]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileModel updateModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var userId = User.FindFirst("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier")?.Value;
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized("User ID not found in token.");
            }

            var result = await _authRepository.UpdateUserProfileAsync(userId, updateModel);
            if (!result)
            {
                return BadRequest(new { message = "Failed to update user profile." });
            }

            return Ok(new { message = "Profile updated successfully." });
        }

    }
}
