﻿using BookStore_Back_Main.Models;
using BookStore_Back_Main.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Identity.Client;

namespace BookStore_Back_Main.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IBookRepository _bookRepository;

        public BooksController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }


        [HttpGet]
        public async Task<IActionResult> GetAllBooks()
        {
            var res = await _bookRepository.GetAllBooksAsync();//לבדוק אולי להעיף את התנאי עי הוא זורק אותנו
            if(res.Count == 0 || res == null)
            {
                return NotFound();
            }
            return Ok(res);
        }


        [HttpPost]
        public async Task<IActionResult> NewBook([FromBody] NewBookModel newBook)
        {
            var res = await _bookRepository.CreateBookAsync(newBook);
            if (res == Guid.Empty)
            {
                return BadRequest();
            }
            return Ok(res);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBookByIdAsync([FromRoute] Guid id)
        {
            var book = await _bookRepository.GetBookByIdAsync(id);
            if (book == null)
            {
                return BadRequest();
            }
            return Ok(book);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateBook([FromBody] NewBookModel updatedBook)
        {
            var success = await _bookRepository.UpdateBookAsync(updatedBook.Id, updatedBook);
            if (!success)
            {
                return NotFound("Book not found.");
            }
            return NoContent();
        }


        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBookAsync([FromRoute] Guid id)
        {
            var res = await _bookRepository.DeleteBookAsync(id);
            if (!res)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}
