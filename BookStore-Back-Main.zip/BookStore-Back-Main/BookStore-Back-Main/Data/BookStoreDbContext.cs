﻿using BookStore_Back_Main.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;


namespace BookStore_Back_Main.Data
{
    public class BookStoreDbContext : IdentityDbContext<UserModel>
    {
        public BookStoreDbContext(DbContextOptions<BookStoreDbContext> options) : base(options) { } 

        public DbSet<BookModel> Books { get; set; }
        public DbSet<UserModel> Users { get; set; }

        public DbSet<CartItemModel> CartItemModel { get; set; }

    }
}
